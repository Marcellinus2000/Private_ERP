'use client'

import React from 'react'
import Link from 'next/link'
import Navimage from './ticket.jpg'
import Image from 'next/image'
import { usePathname } from 'next/navigation'

function Navbar() {

    const currentPath = usePathname();
    const links = [
        {label: 'Dashboard', href:'/'},
        {label: 'Employees', href:'/employees'}
      ]

  return (
    <nav>
        <Image src={Navimage} alt="Tickets Image" width="30"/>
        <h1>KowadaTech</h1>
        <ul className='space-x-5'>
        {links.map(link => <Link 
        key={link.href} href={link.href}
        className={`${link.href === currentPath ? 'text-zinc-900' : 'text-zinc-500'}`}
        >
          {link.label}
        </Link>)}
        </ul>
    </nav>
  )
}

export default Navbar