import React from 'react'
import Image from 'next/image'
import im from '../components/user.jpg'

interface staffDetailsProps {
    fullname: string;
    email: string;
    contact: string;
    location: string;
    position: string;
}

function StaffDetails(props:staffDetailsProps) {

    const {
        fullname, email, contact,location,position
    } = props

    return (
    <div>
        <div className="grid grid-cols-2 gap-2 w-full" >
            <div className='w-9/10'>
                <h5>Staff - {fullname}</h5>
                <div className='big-card'>
                    <div className='items-center flex flex-col'>
                        <Image className='m-5' src={im} alt='' width='90'/>
                    </div>
                    <h5 className='mt-5 p-2 text-secondary font-bold text-sm'>Basic Info</h5>
                </div>

                <div className='small-card'>
                    <h5>Full Name</h5>
                    <h6>{fullname}</h6>
                </div>

                <div className='small-card'>
                    <h5>Email</h5>
                    <h6>{email}</h6>
                </div>

                <div className='small-card'>
                    <h5>Contact</h5>
                    <h6>{contact}</h6>
                </div>

                <div className='small-card'>
                    <h5>Location</h5>
                    <h6>{location}</h6>
                </div>

                <div className='small-card'>
                    <h5>Department</h5>
                    <h6>{"Maintenance"}</h6>
                </div>

                <div className='small-card'>
                    <h5>Position</h5>
                    <h6>{position}</h6>
                </div>

                <div className='small-card'>
                    <h5>Salary</h5>
                    <h6>{"$1000"}</h6>
                </div>

                <div className='mt-8'>
                    <div className='big-card'>
                        <div className='p-3'>
                            <h5>Bank Details</h5>
                            <div className='mt-5 flex justify-between items-center'>
                                <h6>Bank Name</h6>
                                <h6>Access Bank</h6>
                            </div>
                            
                            <div className='pt-2 flex justify-between items-center'>
                                <h6>Account Number</h6>
                                <h6>363783330398834</h6>
                            </div>

                            <div className='pt-2 items-center flex justify-between'>
                                <h6>Branch</h6>
                                <h6>Tarkwa</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div className='w-full mx-4'>
                <div className='mt-7 flex space-x-5'>
                    <div className='medium-card'>
                        <div className='p-5'>
                            <h5>Days of Leave</h5>
                            <h5>0/15</h5>
                        </div>
                    </div>

                    <div className='medium-card'>
                        <div className='p-5'>
                            <h5>Medical Leave</h5>
                            <h5>2</h5>
                        </div>
                    </div>

                    <div className='medium-card'>
                        <div className='p-5'>
                            <h5>Days of Leave</h5>
                            <h5>0/15</h5>
                        </div>
                    </div>
                </div>

                <div className='big-card'>

                </div>

                <div className='big-card'>

                </div>

                <div className='flex'>
                    <div className='big-card'>

                    </div>

                    <div className='big-card'>

                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default StaffDetails
