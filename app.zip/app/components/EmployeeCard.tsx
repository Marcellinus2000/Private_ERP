import React from 'react'
import Link from 'next/link'
import Image from 'next/image'
import user from '../components/user.jpg'
import mail from '../components/email.jpeg'
import phone from '../components/telephoneIcon.jpeg'
import {Icon} from '@iconify/react'
import viewIcon from '@iconify-icons/feather/eye';
import editIcon from '@iconify-icons/feather/edit';
import deleteIcon from '@iconify-icons/feather/trash-2';
import { useState } from 'react'

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  otherName: string;
  contact: string;
  userEmail: string;
  positionHeld: string;
}

function EmployeeCard(props:Employee) {

  const {
    id,firstName, otherName, lastName, userEmail, contact ,positionHeld
} = props

  const [isVisible, setVisisble] = useState(false);

  const handleVerticalClick = () => {
    setVisisble(!isVisible);
  }

  return (
    <div className='card relative'>
      <li key={id}>
            <div className='flex justify-between'>
              <span>
                {
                  isVisible && (
                  <div className="absolute right-3 my-3 px-2 shadow-sm z-1">
                    <div className="text-sm bg-offwhite rounded-lg">
                      <div className="flex items-center space-x-2 p-2">
                        <Icon icon={viewIcon} width="12" height="12" />
                        <span><Link href={`/employees/v?id=${id}`}>View</Link></span>
                      </div>
                      <div className="flex items-center space-x-2 p-2">
                        <Icon icon={editIcon} width="12" height="12" />
                        <span className='text-sm'>Update</span>
                      </div>
                      <div className="flex items-center space-x-2 p-2">
                        <Icon icon={deleteIcon} width="12" height="12"/>
                        <span>Delete</span>
                      </div>
                    </div>
                  </div>
                  )}
              </span>
              <div className='rounded-md bg-customBlue p-1/3'>
                <Icon onClick={handleVerticalClick} icon="feather:more-vertical" width="24" height="24" color='white'/>
              </div>
            </div>

            <div className='flex flex-col justify-center items-center'>
              <Image src={user} alt='' width='50'/>                  
              <h3>{firstName} {otherName} {lastName}</h3>
            </div>
          
          <div className='flex flex-col items-center my-2'>
            <div className='m-0 text-sm'>Position Held</div>
            <div className='text-secondary text-sm'>{positionHeld}</div>
          </div>

          <div>
            <div className='flex items-center space-x-2 mb-2'>
              <Image src={phone} alt='phoneIcon' />
              <div className='text-red-500 text-sm'>{contact}</div>
            </div>

            <div className='flex items-center space-x-2'>
              <Image src={mail} alt='mailIcon' />
              <div className='text-secondary text-sm'>{userEmail}</div>
            </div>
          </div>
      </li>

    </div>
  )
}

export default EmployeeCard