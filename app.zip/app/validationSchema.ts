import { z } from 'zod';

const parseDate = (dateString: string): Date => {
  const parsedDate = new Date(dateString);
  if (isNaN(parsedDate.getTime())) {
    throw new Error('Invalid date format');
  }
  return parsedDate;
};


export const createEmployeeSchema = z.object({
  firstName: z.string().min(1, 'First Name is required'),
  lastName: z.string().min(1, 'Last Name is required'),
  otherName: z.string().optional(),
  dateOfBirth: z.string().refine(dateString => parseDate(dateString)),
  contact: z.string().min(10, 'Provide a valid contact number'),
  userEmail: z.string().email('Invalid email format'),
  residence: z.string().min(1, 'Residence is required'),
  dateOfAppointment: z.string().refine(dateString => parseDate(dateString)),
  positionHeld: z.string().min(1, 'Position is required'),
  description: z.string()
});

