import { NextResponse } from "next/server";
import prisma from "@/prisma/client";

export async function GET() {
  
  try {
    const employees = await prisma.employee.findMany();
    return NextResponse.json(employees, { status: 200 });
  } 
  
  catch (error) {
    console.error("Error fetching employees:");
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}