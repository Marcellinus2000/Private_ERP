import { NextRequest, NextResponse } from "next/server"
import prisma from "@/prisma/client";
import { createEmployeeSchema } from "@/app/validationSchema";

export async function POST(request: NextRequest) {
  const body = await request.json();
  
  const validation = createEmployeeSchema.safeParse(body);

  if(!validation.success)
  return NextResponse.json(validation.error.format(), {status:400})

  const newEmployee = await prisma.employee.create({
    data: {
      firstName: body.firstName,
      lastName: body.lastName,
      otherName: body.otherName,
      dateOfBirth: new Date(body.dateOfBirth),
      contact: body.contact,
      userEmail: body.userEmail,
      residence: body.residence,
      dateOfAppointment: new Date(body.dateOfAppointment),
      positionHeld: body.positionHeld,
      description: body.description,
    },
  });

  return NextResponse.json(newEmployee, {status:201})
}
