// Import necessary modules and dependencies

import { NextRequest, NextResponse } from "next/server";
import prisma from "@/prisma/client";


export async function GET(req:Request, {params: {id}}:{params:any}) {
  try {
    
    const empid = parseInt(id)

    if (!id) {
      return NextResponse.json(
        { error: "Employee ID is required in the query parameters" },
        { status: 400 }
      );
    } 

    const employee = await prisma.employee.findFirst({
      where: { id: empid }
    });

    if (!employee) {
      return NextResponse.json({ error: "Employee not found" }, { status: 404 });
    }

    return NextResponse.json(employee, { status: 200 });
  } 
  
  catch (error) {
    console.error("Error fetching employee:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest, { params: { id } }: { params: any }) {
  try {
    const empId = parseInt(id);
    

    if (!id) {
      return NextResponse.json(
        { error: 'Employee ID is required in the query parameters' },
        { status: 400 }
      );
    }

    const existingEmployee = await prisma.employee.findFirst({
      where: { id: empId },
    });

    if (!existingEmployee) {
      return NextResponse.json({ error: 'Employee not found' }, { status: 404 });
    }
    
    const {firstName, lastName, otherName, contact, dateOfBirth, dateOfAppointment, residence,positionHeld, userEmail} = await req.json();

    const updatedEmployee = await prisma.employee.update({
      where: { id: empId },
      data: {
        firstName, lastName,otherName,contact,userEmail,
        positionHeld,dateOfAppointment,dateOfBirth,residence
      },
    });

    return NextResponse.json(updatedEmployee, { status: 200 });
  } 
  catch (error) {
    console.error('Error updating employee:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
