
export default function Home() {
  return (
    <main>
      <h1>
        Dashboard
      </h1>
    </main>
  );
}