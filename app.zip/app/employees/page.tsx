'use client'


import React, {useState, useEffect, FC} from 'react'
import Link from 'next/link'
import axios from 'axios'
import EmployeeCard from '../components/EmployeeCard'

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  otherName: string;
  userEmail: string;
  contact: string;
  positionHeld:string;
}

const page:FC = () => {

  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('/api/employees');
        setEmployees(response.data);
      } 
      
      catch (error) {
        console.error('Error fetching employees:', error);
      } 
      
      finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <main>

      <nav className='justify-between items-center'>
        <h2 className='text-secondary'>Staff Details</h2>
      <button className='btn-primary'>
        <Link href='/employees/new'>
          Add New Staff
        </Link>
      </button>
      </nav>

      <div className='my-10'>
      {isLoading ? (  <p>Loading...</p>) : (
        <div className='max-w-950 mx-auto'>
          
          <ul className='flex flex-wrap my-5'>
          {employees.map((employee) => 
            <EmployeeCard id={employee.id} firstName={employee.firstName} otherName={employee.otherName} lastName={employee.lastName} userEmail={employee.userEmail} contact={employee.contact} positionHeld={employee.positionHeld}/>
          )}
        </ul>
        </div>
      )}
    </div>
      
    </main>
  )
}

export default page
