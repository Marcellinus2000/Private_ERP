'use client'

import React, { useState, useEffect } from 'react';
import {  useSearchParams } from 'next/navigation';
import axios from 'axios';
import StaffDetails from '@/app/components/StaffDetails';

interface Employee {
    firstName: string;
    otherName: string;
    lastName: string;
    userEmail: string;
    contact: string;
    residence: string; 
    positionHeld: string;
    
  }

const EmployeeDetailsPage = () => {

  const employeeId = useSearchParams();
  const  id = employeeId.get("id"); 

  
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      
        try {
        setIsLoading(true);

        const response = await axios.get(`/api/employees/${id}`);

        setEmployee(response.data);

      } 

      catch (error) 
      {
        console.error('Error fetching employee details:', error);
        setError('Error fetching employee details');
      } 
      
      finally {
        setIsLoading(false);
      }
    };

    if (id) {
      fetchData();
    }
  }, [id]); 

  return (
    <main>
      {isLoading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>{error}</p>
      ) : employee ? (
        <StaffDetails
        fullname={`${employee.firstName} ${employee.otherName} ${employee.lastName}`}
        email={employee.userEmail}
        contact={employee.contact}
        location={employee.residence}
        position={employee.positionHeld}
      />
      ) : (
        <p>No employee found</p>
      )}
    </main>
  );
};

export default EmployeeDetailsPage;