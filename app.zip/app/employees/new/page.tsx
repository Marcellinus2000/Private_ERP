'use client'
import React, {useState} from 'react'
import { useRouter } from 'next/navigation'
import {Button, Callout,  TextField} from '@radix-ui/themes'
import DatePicker from 'react-datepicker';
import SimpleMdeReact from 'react-simplemde-editor';
import "easymde/dist/easymde.min.css";
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod';
import { createEmployeeSchema } from '@/app/validationSchema'
import axios from 'axios'
import {z} from 'zod'
import Spinner from '../../components/Spinner'
import 'react-datepicker/dist/react-datepicker.css'
import ErrorMsg from '@/app/components/ErrorMsg';


type EmployeeForm = z.infer<typeof createEmployeeSchema>

const NewEmployeePage = () => {
  
  const router = useRouter()
  const {register, control, handleSubmit, formState:{errors}} = useForm<EmployeeForm>({
    resolver:zodResolver(createEmployeeSchema)
  })
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

   

  const submitForm = handleSubmit(async (data) => {
    
    try{

      setIsSubmitting(true)
      await axios.post('http://localhost:3000/api/employees/create', data)
      router.push('/employees')
    }
    catch (error) {
        setIsSubmitting(false)
        setError('An unexpected error occured')
    }
  })
  
return (
    <main>
      {error && (<Callout.Root color='red' className='max-w-xl space-y-4 mb-4'>
      <Callout.Text>{error}</Callout.Text>
      </Callout.Root>)}

    <form className='max-w-xl space-y-4' onSubmit={submitForm}>

      <div className="grid grid-cols-3 gap-4">

        <div>
          <TextField.Root>
            <TextField.Input
              placeholder='First Name'
              {...register('firstName')}
              className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
            />
          </TextField.Root>
          <ErrorMsg>{errors.firstName?.message}</ErrorMsg>
        </div>

        <div>
          <TextField.Root>
            <TextField.Input
              placeholder='Last Name'
              {...register('lastName')}
              className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
            />
          </TextField.Root>
          <ErrorMsg>{errors.lastName?.message}</ErrorMsg>
        </div>

        <div>
          <TextField.Root>
            <TextField.Input
              placeholder='Other Name'
              {...register('otherName')}
              className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
            />
          </TextField.Root>
          <ErrorMsg>{errors.otherName?.message}</ErrorMsg>
        </div>

        <div>
          <Controller
            name='dateOfBirth'
            control={control}
            render={({ field }) => (
              <div>
                <DatePicker
                  placeholderText='Select Date of Birth'
                  dateFormat='yyyy-MM-dd'
                  onChange={(date) => field.onChange(date?.toISOString().split('T')[0] || '')}
                  selected={field.value ? new Date(field.value) : null}
                  className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
                />
                <ErrorMsg>{errors.dateOfBirth?.message}</ErrorMsg>
              </div>
            )}
          />
        </div>

        <div>
          <TextField.Root>
            <TextField.Input
              placeholder='Contact'
              {...register('contact')}
              className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
            />
          </TextField.Root>
          <ErrorMsg>{errors.contact?.message}</ErrorMsg>
        </div>

        <div>
          <TextField.Root>
            <TextField.Input
              placeholder='User Email'
              {...register('userEmail')}
              className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
            />
          </TextField.Root>
          <ErrorMsg>{errors.userEmail?.message}</ErrorMsg>
        </div>

        <div>
          <Controller
            name='dateOfAppointment'
            control={control}
            render={({ field }) => (
              <div>
                <DatePicker
                  placeholderText='Select Date of Appointment'
                  dateFormat='yyyy-MM-dd'
                  onChange={(date) => field.onChange(date?.toISOString().split('T')[0] || '')}
                  selected={field.value ? new Date(field.value) : null}
                  className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
                />
                <ErrorMsg>{errors.dateOfAppointment?.message}</ErrorMsg>
              </div>
            )}
          />
        </div>

        <div>
          <TextField.Root>
            <TextField.Input
              id='residence'
              placeholder='Residence'
              {...register('residence')}
              className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
            />
          </TextField.Root>
          <ErrorMsg>{errors.residence?.message}</ErrorMsg>
        </div>

        <TextField.Root>
          <TextField.Input placeholder='Position Held' {...register('positionHeld')} 
          className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'/>
          <ErrorMsg>{errors.positionHeld?.message}</ErrorMsg>
        </TextField.Root>

        <TextField.Root>
          <TextField.Input placeholder='Salary' 
          className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'/>
          <ErrorMsg>{errors.positionHeld?.message}</ErrorMsg>
        </TextField.Root>

        <TextField.Root>
          <label> Select Image</label>
          <TextField.Input
          type='file'/>
        </TextField.Root>

        <TextField.Root>
          <label> Other Documents</label>
          <TextField.Input
          type='file'/>
        </TextField.Root>

        <TextField.Root>
          <label> CV</label>
          <TextField.Input
          type='file' />
        </TextField.Root>

        <div className="col-span-3"> {/* Full width for the textarea */}
          <Controller
            name='description'
            control={control}
            render={({ field }) => (
              <SimpleMdeReact
                placeholder='Description'
                {...field}
                className='border border-violet-200 rounded px-3 py-2 focus:outline-none focus:border-violet-dark w-full'
              />
            )}
          />
        </div>

      </div>
    

      <Button
        disabled={isSubmitting}
        className={`bg-primary text-white px-4 py-2 rounded ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        Add New Staff {isSubmitting && <Spinner />}
      </Button>
    </form>
  </main>
  )
}

export default NewEmployeePage